Hello,

To install WRobot:
- Launch file "Updater.exe".
- (you can select version of WRobot in "Product").
- Click the button "Install or Update".
- When the update or install is finished, you can close this program and launch WRobot.exe from the installed directory.


If you get problem, you need to install:
- Framework: https://www.microsoft.com/en-us/download/details.aspx?id=48130
- DirectX: https://www.microsoft.com/en-us/download/details.aspx?id=35&fa43d42b-25b5-4a42-fe9b-1634f450f5ee=True
- SlimDX (4.0 X86): https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/slimdx/SlimDX%20Runtime%20.NET%204.0%20x86%20(January%202012).msi
- Redistributable Visual C + + 2010 (X86): http://www.microsoft.com/en-us/download/details.aspx?id=5555

How to Repair/Install WRobot: https://wrobot.eu/forums/topic/1381-repairinstall-wrobot/#comment-966

Regards, Droidz / https://wrobot.eu/